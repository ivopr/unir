#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char nome[50], ender[50], ra[50];
} aluno;

void escreveRegVar();
void leRegVar();
void escreveRegFix();
void leRegFix();

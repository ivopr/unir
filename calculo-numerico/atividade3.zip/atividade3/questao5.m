# Questão 5

# A
A = [
   12   3  4;
   24  -1  6;
  -12 -17 14;
];

[newA] = triangulador(A);

newA

# B
B = [
   2  0  9  0;
   6  5 33  4;
   2 -5 10  2;
  -8 10 11 47;
];

[newB] = triangulador(B);

newB

C = [
   21  -3   4   9 -23;
  -84  19  18 -36  92;
  -42  27 -20 -14  46;
   21 -24   4  16 -21;
   84   2  42  25 -94;
];

[newC] = triangulador(C);

newC


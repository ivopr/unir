function [x] = questao6(A, b)
  [l, c] = size(A);

  if(l != c)
    return
  endif

  [A, t] = verificaTriangulacao(A);
  [n, ~] = size(A);

  if(t == 2)
    x = substituicaoDireta(A, b, n);
    return
  endif

  if(t == 1)
    x = substituicaoReversa(A, b, n);
    return
  endif
endfunction
